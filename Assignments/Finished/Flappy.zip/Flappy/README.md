# PierreAnken

Changes done
- Order assets in specifics folders
- Medals depending on score (0 / <3 / >=3)
- Pause with P