# Extension from PierreAnken

Added features:
- Selection of number of Ai players on start
- Velocity display
- Velocity increased in Ai only matches
- Ai move to center of screen if not receiving the ball else towars ball center
- - Buffer on Ai move to disable permanant position correction
- Auto serving for Ai
- Ne home key to quit current game without leaving the game